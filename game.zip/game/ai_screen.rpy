# ============================================================
# AI 聊天界面
# ------------------------------------------------------------
# 两种进入方式：
#   1) 剧情独处节点：call screen ai_chat_screen（free_mode=False）
#   2) 右上角常驻按钮：随时 Show 同一个界面（free_mode=True）
# 吵架 / 真相 / 结局段落会把 ai_free_chat 关掉，按钮自动消失。
# ============================================================

style ai_bubble is frame:
    padding (16, 12)
    xmaximum 460

style ai_bubble_text is text:
    size 22
    line_spacing 4

style ai_input is input:
    size 22
    color "#3a2b28"


init python:
    # 常驻 HUD：比 show screen 更稳，读档后也不会丢
    if "ai_chat_button" not in config.overlay_screens:
        config.overlay_screens.append("ai_chat_button")


# 右上角常驻入口：配置好、在线、且不在关键剧情时显示
screen ai_chat_button():
    zorder 40

    if ai_chat_visible():
        frame:
            xalign 0.985
            yalign 0.025
            padding (12, 6)
            background Solid("#00000088")

            textbutton "和舒瑶说说话":
                action [Function(ai_open_chat), Show("ai_chat_screen", free_mode=True)]
                text_size 17
                text_color "#efe1d9"


screen ai_chat_screen(free_mode=False):
    modal True
    zorder 200

    # screen 内先算好文案，避免在文本插值里调用函数
    $ mood_text = ai_mood_short()
    $ subtitle = ("自由聊天 | 她" + mood_text) if free_mode else ("她在这里，" + mood_text + "。")
    $ turns_left = ai_turns_left()
    $ left_hint = (" | 还能聊 %d 句" % turns_left) if turns_left <= 15 else ""
    $ status_line = "第 %d 天 | 好感 %d | %s | %s%s" % (current_day, affection, ai_relation_label(), ai_status_text(), left_hint)
    $ portrait = "awan hurt" if quarrel_severity >= 1 else ("awan happy" if affection >= 60 else "awan calm")

    # 半透明遮罩
    add Solid("#00000099")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 780
        ysize 660
        padding (28, 22)
        background Solid("#fbf7f4")

        vbox:
            spacing 10

            # 标题栏
            hbox:
                spacing 12
                add portrait xysize (72, 144)
                vbox:
                    spacing 2
                    text "舒瑶" size 30 color "#3a2b28"
                    text subtitle size 18 color "#8a7f7a"
                    text status_line size 16 color "#a09590"

            # 对话历史
            frame:
                xsize 724
                ysize 400
                padding (12, 12)
                background Solid("#ffffff")

                viewport:
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    yinitial 1.0

                    vbox:
                        spacing 10
                        for m in ai_messages:
                            frame:
                                style "ai_bubble"
                                xalign (1.0 if m["role"] == "user" else 0.0)
                                background Solid("#f2dfd8" if m["role"] == "user" else "#f2f4f7")
                                text m["content"] style "ai_bubble_text" color "#3a2b28"

                        if ai_pending:
                            text "舒瑶正在想……" size 18 color "#a09590"

            # 输入行
            hbox:
                spacing 10
                frame:
                    xsize 560
                    ysize 52
                    padding (14, 12)
                    background Solid("#ffffff")
                    input value VariableInputValue("ai_input") length 200 style "ai_input"

                textbutton "发送":
                    action Function(ai_send)
                    sensitive (not ai_pending)
                    text_size 20

            # 状态与退出
            hbox:
                spacing 16
                textbutton "结束聊天":
                    action (Hide("ai_chat_screen") if free_mode else Return())
                    text_size 20

                textbutton "让她重说一次":
                    action Function(ai_regenerate)
                    sensitive (not ai_pending and len(ai_messages) > 0 and ai_messages[-1]["role"] == "assistant")
                    text_size 18

                if ai_error:
                    text ai_error size 17 color "#c24f44" xmaximum 420

    key "K_ESCAPE" action (Hide("ai_chat_screen") if free_mode else Return())


# 在独处节点调用：有配置且在线才给入口，否则静默跳过
label ai_optional_chat:
    if not ai_chat_enable:
        return
    if not ai_is_configured():
        return
    if not ai_online:
        return

    $ ai_open_chat()
    menu:
        "想和她说说话。":
            call screen ai_chat_screen
        "就这样安静地待一会儿。":
            pass
    return
