# ============================================================
# 《旧信箱里的拾信者》· 基础定义
# 变量 / 角色 / 占位素材 / 立绘位置 / 常量
# ------------------------------------------------------------
# 说明：本项目不附带美术与音频素材，所有背景与立绘均为纯色占位，
#      并已在注释里标好应当替换的文件名，直接替换同名图片即可。
# ============================================================

# ---------- 角色 ----------
# 男主：胡云砚（第一人称，对话框显示「我」）
define me = Character("我", color="#9fb6d4")
# 女主：安舒瑶，平辈称呼「舒瑶」
define awan = Character("舒瑶", color="#e8b4a8")
define awan_low = Character("舒瑶", color="#c9a89c", what_prefix="……", what_suffix="")
define letter = Character("信", color="#d9cba8", what_italic=True)

# 路人（一次性角色，避免用字符串充当说话者）
define boss = Character("老板娘", color="#c9b9a6")
define old_man = Character("渔船上的老人", color="#c9b9a6")
define clerk = Character("售票员", color="#c9b9a6")
define fish_aunt = Character("卖鱼的阿姨", color="#c9b9a6")

# ---------- 核心变量（剧情分支依赖，切勿改名） ----------
default affection = 0          # 好感
default quarrel_severity = 0   # 吵架严重度：0 轻微 / 1 中等 / 2 重度
default memory_piece = 0       # 回忆碎片计数
default ai_chat_enable = False # 剧情节点的 AI 入口开关
default ai_free_chat = True    # 是否允许随时找舒瑶聊天（吵架/真相/结局关闭）

# ---------- 流程变量 ----------
default current_day = 1               # 故事内的第几天（1~7）
default current_stage = "第一幕"     # 传给 AI 的剧情阶段描述
default stage_info = "海边初遇，傍晚的堤岸"
default visited_places = []          # 一起逛过的地方（传给 AI 记忆）
default unlocked_sides = []          # 本周目已解锁的支线 label
default free_roam_used = 0           # 自由闲逛次数
default truth_known = False          # 男主是否已知真相（AI 防剧透依据）

# ---------- AI 聊天变量（随存档保存） ----------
default ai_messages = []     # [{"role": "user"/"assistant", "content": "..."}]
default ai_input = ""        # 输入框内容
default ai_pending = False   # 是否有请求在飞
default ai_online = True     # 启动探测结果：无网络时隐藏入口
default ai_error = ""        # 最近一次错误提示
default ai_turn_count = 0    # 本次游玩已经发出的模型请求数

# ---------- 常量 ----------
define MEMORY_TOTAL = 7           # 回忆碎片总数（7 个城市地点各 1 片）
define AFFECTION_TRUE_END = 100   # 隐藏好结局好感门槛（七天全流程满分约 111）
define AFFECTION_GE = 35          # 预留参考线（当前结局判定未使用）
define AI_MAX_TURNS = 40          # 传给模型的历史对话上限（条）
define AI_TURN_LIMIT_DEFAULT = 120  # 每次游玩的模型请求上限（含「重说」）

# 城市支线池：自由闲逛时从未解锁项里随机抽
define SIDE_STORIES = [
    "side_dessert_shop",
    "side_night_market",
    "side_bookstore",
    "side_ferris_wheel",
    "side_riverside",
    "side_record_store",
    "side_bus_stop",
]

# ---------- 二周目 ----------
init python:
    if persistent.new_game_plus is None:
        persistent.new_game_plus = False
    if persistent.cleared_ending is None:
        persistent.cleared_ending = ""


# ---------- 共用流程函数 ----------
init -5 python:
    def visit_place(name, piece=True):
        """首次到达某地点：记录足迹，并给一片回忆碎片。"""
        if name in store.visited_places:
            return False
        store.visited_places.append(name)
        if piece:
            store.memory_piece += 1
            if store.memory_piece <= store.MEMORY_TOTAL:
                renpy.notify("获得回忆碎片 %d / %d" % (store.memory_piece, store.MEMORY_TOTAL))
        return True

    def add_affection(value):
        store.affection = max(0, store.affection + value)

    def raise_quarrel(value):
        store.quarrel_severity = min(2, max(store.quarrel_severity, value))


# ============================================================
# 占位素材
# ------------------------------------------------------------
# 背景：正式素材请放到 game/images/bg/<name>.png，
#      然后把下一行的 Solid 换成 image bg xxx = "images/bg/xxx.png"
# 立绘：正式素材建议 720x1440 透明 PNG，命名 awan_<表情>.png
# ============================================================

image bg sea_dusk = Solid("#233246")
image bg bus_window = Solid("#2a3448")
image bg dessert_shop = Solid("#3a2f2a")
image bg night_market = Solid("#2e2438")
image bg bookstore = Solid("#332b22")
image bg ferris_wheel = Solid("#1f2c3d")
image bg riverside = Solid("#1c2a36")
image bg record_store = Solid("#2b2622")
image bg bus_stop = Solid("#151b26")
image bg mailbox = Solid("#2a2f38")
image bg town_day = Solid("#3b3a33")
image bg room = Solid("#2a2622")
image bg festival_night = Solid("#241d2e")
image bg black = Solid("#000000")
image bg white = Solid("#ffffff")

# 舒瑶的六种状态：平静 / 害羞 / 欢喜 / 落寞 / 委屈 / 含泪透明
init -1 python:
    def awan_stand(label, color, alpha=1.0):
        """生成占位立绘：色块 + 状态文字。正式素材直接替换 image 语句即可。

        透明度直接写进颜色（#RRGGBBAA），避免给 Fixed 传 displayable 属性。
        """
        level = int(max(0.0, min(1.0, alpha)) * 255)
        fill = "%s%02x" % (color, level)
        return Fixed(
            Solid(fill, xsize=360, ysize=720),
            Text(label, size=26, color="#3a2b28", xalign=0.5, yalign=0.5),
            xysize=(360, 720),
        )

image awan calm = awan_stand("舒瑶 · 平静", "#e6c6b6")
image awan shy = awan_stand("舒瑶 · 害羞", "#f0b9a8")
image awan happy = awan_stand("舒瑶 · 欢喜", "#f4c9a6")
image awan lonely = awan_stand("舒瑶 · 落寞", "#b9b3ba")
image awan hurt = awan_stand("舒瑶 · 委屈", "#c9a7a7")
image awan fading = awan_stand("舒瑶 · 含泪透明", "#a9c2cf", alpha=0.42)

# ---------- 立绘位置 / 演出 ----------
transform awan_center:
    xalign 0.5
    yalign 1.0

transform awan_left:
    xalign 0.24
    yalign 1.0

transform awan_right:
    xalign 0.76
    yalign 1.0

transform soft_in:
    alpha 0.0
    linear 0.5 alpha 1.0

transform fade_black:
    alpha 0.0
    linear 1.2 alpha 1.0

# ---------- 转场 ----------
define fade_scene = Fade(0.5, 0.2, 0.6, color="#000000")
define slow_scene = Dissolve(1.2)
# 告别段落用的长淡出
define fade_slow = Dissolve(1.6)
