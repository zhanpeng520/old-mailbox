# ============================================================
# 项目配置（PC / Android 打包相关）
# iOS 需要 macOS + Xcode 环境，Ren'Py 支持但需在 Mac 上构建
# ============================================================

define config.name = _("旧信箱里的拾信者")
define config.version = "0.1.0"
define build.name = "OldMailboxLetters"

# 官方 screens.rpy / gui.rpy 依赖的变量（模板里写在 options.rpy 中）
define gui.show_name = True
define gui.about = _p("""
《旧信箱里的拾信者》

一个关于海边、旧信箱和七天相处的故事。
""")

define config.save_directory = "OldMailboxLetters-20261105"
define config.window_title = "旧信箱里的拾信者"

define config.has_sound = True
define config.has_music = True
define config.has_voice = False

# 默认文本速度与自动前进行为：偏慢，留出情绪
default preferences.text_cps = 32
default preferences.afm_time = 12

define config.enter_transition = dissolve
define config.exit_transition = dissolve
define config.intra_transition = dissolve
define config.after_load_transition = None
define config.end_game_transition = fade

# 主菜单与游戏内音乐（素材缺失时留空即可）
# define config.main_menu_music = "audio/main_theme.ogg"

# ---------- 打包 ----------
init python:
    build.classify("**~", None)
    build.classify("**.bak", None)
    build.classify("**/.**", None)
    build.classify("**/#**", None)
    build.classify("**/thumbs.db", None)

    # 文档与密钥不进包体：ai_config.json 含真实 key，任何分发包（含 Web）都不带
    # 桌面包要单独配 key 时，把 ai_config.json 放进安装目录的 game/ 下即可
    build.classify("game/README.md", None)
    build.classify("game/ai_config.example.json", None)
    build.classify("game/ai_config.json", None)

    build.documentation("README.md")

    # Android / PC 通用构建
    build.name = "OldMailboxLetters"
